import { handlers } from "@/app/auth"

export const { GET, POST } = handlers